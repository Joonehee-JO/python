from django.shortcuts import render, redirect
from websites import templates
from .models import User
# Create your views here.
def login(request) :
    if request.method == "POST" :
        users = User.objects.all()
        ID = request.POST.get('ID')
        password = request.POST.get('password')
        for item in users :
            if item.User_id == ID :
                user = User.objects.get(User_id=ID)
                if user.pw == password :
                    login = int(1)
                    logout = int(1)
                    return render(request, 'main.html', {'login':login, 'logout':logout})
                else :
                    error = int(1)
                    return render(request, 'login.html', {'error':error})
        error = int(1)
        return render(request, 'login.html', {'error':error})
    return render(request, 'login.html')


def signup(request) :
    if request.method == "POST" :
        ID = request.POST.get('ID')
        password = request.POST.get('password')
        password_again = request.POST.get('password_again')
        name = request.POST.get('name')
        users = User.objects.all()
        for item in users :
            if item.User_id == ID :
                error = int(2)
                return render(request, 'signup.html', {'error':error})
        if password_again != password :
            error = int(1)
            return render(request, 'signup.html', {'error':error})
        user = User(name=name, pw=password, User_id=ID)
        user.save()
        return redirect('login')
    return render(request, 'signup.html')

class status :
    client = 0
    def login_(self) :
        self.client = 1
    
    def logout_(self) :
        self.client = 0



def x(a) :
    login = 0
    login_ = login+a
    return login_