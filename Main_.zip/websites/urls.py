from django.urls import path
from . import views

urlpatterns = [
    path('bottom/', views.bottom, name="bottom"),
    path('men/', views.men, name="men"),
    path('outer/', views.outer, name="outer"),
    path('top/', views.top, name="top"),
    path('women/', views.women, name="women"),
]