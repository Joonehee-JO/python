from django.urls import path
from . import views

urlpatterns = [
    path('bottom/', views.bottom, name="bottom"),
    path('main_1/<char:name>/', views.main_1, name="main_1"),
    path('men/', views.men, name="men"),
    path('outer/', views.outer, name="outer"),
    path('top/', views.top, name="top"),
    path('women/', views.women, name="women"),
]