from django.shortcuts import render
from users.views import x
from users.models import User
# Create your views here.
def main(request):
    login = 0
    return render(request, 'main.html', {'login':login})

def main_1(request, name) :
    user = User.objects.get(name=name)
    login = 1
    return render(request, 'main.html', {'login':login, 'user':user})


def bottom(request) :
    return render(request,'bottom.html')


def login(request) :
    return render(request,'login.html')


def men(request) :
    return render(request,'men.html')


def outer(request) :
    return render(request,'outer.html')


def signup(request) :
    return render(request,'signup.html')


def top(request) :
    return render(request,'top.html')


def women(request) :
    return render(request,'women.html')